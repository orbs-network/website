---
layout: partials/home/cards/main/index
type: contributor
title: talkol
links:
  - github.md
lat: 31.5313113
lng: 34.8667654
countryCode: IL
image: /assets/img/home/contributors/tal.png
---

Interests: react, javascript, mobile
