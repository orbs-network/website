---
layout: partials/home/cards/components/link
text: link to github
url: https://github.com/talkol
image: /assets/img/socials/github.svg
---
