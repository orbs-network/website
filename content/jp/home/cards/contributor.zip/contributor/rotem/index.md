---
layout: partials/home/cards/main/index
type: contributor
title: Rotemy
links:
  - github.md
lat: 31.5313113
lng: -90.026573
countryCode: US
image: /assets/img/home/contributors/rotem.jpeg
---

Interests: Front-end, UI/UX
