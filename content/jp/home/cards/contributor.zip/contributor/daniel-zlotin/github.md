---
layout: partials/home/cards/components/link
text: Link to github
url: https://github.com/DanielZlotin

image: /assets/img/socials/github.svg
---
