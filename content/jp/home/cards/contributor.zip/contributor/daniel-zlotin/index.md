---
layout: partials/home/cards/main/index
type: contributor
title: DanielZlotin
links:
  - github.md
lat: 31.5313113
lng: -90.026573
countryCode: US
image: /assets/img/home/contributors/daniel.png
---

Interests: DeFi, Trading strategies
