---
layout: partials/home/cards/components/link
text: Link to github
url: https://github.com/daviddayag
image: /assets/img/socials/github.svg
---
