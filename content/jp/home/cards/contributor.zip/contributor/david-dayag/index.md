---
layout: partials/home/cards/main/index
type: contributor
title: David Dayag
links:
  - github.md
lat: 31.5313113
lng: 34.8667654
countryCode: IL
image: /assets/img/home/contributors/david.jpeg
---

Interests: Finance, Crypto, ML
