---
layout: partials/home/cards/container/index
list:
  - tal-kol/index.md
  - ron-bresler/index.md
  - doron-aviguy/index.md
  - david-dayag/index.md
  - daniel-zlotin/index.md
  - amihaz/index.md
  - jtunis/index.md
  - rotem/index.md
  - uv-orbs/index.md
---
