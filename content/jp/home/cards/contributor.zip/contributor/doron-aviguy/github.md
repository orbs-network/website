---
layout: partials/home/cards/components/link
text: link to github
url: https://github.com/doronaviguy
image: /assets/img/socials/github.svg
---
