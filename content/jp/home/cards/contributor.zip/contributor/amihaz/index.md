---
layout: partials/home/cards/main/index
type: contributor
title: amihaz
links:
  - github.md
lat: 31.5313113
lng: -90.026573
countryCode: US
image: /assets/img/home/contributors/amihaz.jpeg
---

Interests: Big data, options trading
