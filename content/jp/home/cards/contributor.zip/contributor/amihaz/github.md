---
layout: partials/home/cards/components/link
text: Link to github
url: https://github.com/amihaz
image: /assets/img/socials/github.svg
---
