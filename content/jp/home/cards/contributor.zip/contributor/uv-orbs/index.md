---
layout: partials/home/cards/main/index
type: contributor
title: uv-orbs
links:
  - github.md
lat: 31.5313113
lng: -90.026573
countryCode: US
image: /assets/img/home/contributors/uv.png
---

Interests: DeFi, Keto
