---
layout: partials/home/cards/components/link
text: link to github
url: https://github.com/ronnno
image: /assets/img/socials/github.svg
---
