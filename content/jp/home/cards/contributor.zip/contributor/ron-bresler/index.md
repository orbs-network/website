---
layout: partials/home/cards/main/index
type: contributor
title: ronnno
links:
  - github.md
lat: 31.5313113
lng: 34.8667654
countryCode: IL
image: /assets/img/home/contributors/ron.jpeg
---

Interests: Distributed systems, Go, Blockchain
